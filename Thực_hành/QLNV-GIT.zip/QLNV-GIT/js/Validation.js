function Validation() {
  // khac nhau validation cua form
  /**
   * 1. Id
   * 2. Noi dung lỗi
   * 3. value
   */

  this.checkEmpty = function (inputValue, id, message) {
    // trim : remove space de check validate
    if (inputValue.trim() === '') {
      document.getElementById(id).style.display = 'block';
      document.getElementById(id).innerHTML = message;
      return false;
    } else {
      document.getElementById(id).style.display = 'none';
      document.getElementById(id).innerHTML = '';
      return true;
    }
  };

  this.checkTK = function (inputValue, id, message, listEmployee) {
    var index = listEmployee.findIndex(
      (item) => item.taiKhoan === inputValue.trim()
    );

    // nếu tồn tại thì báo lỗi
    if (index !== -1) {
      document.getElementById(id).style.display = 'block';
      document.getElementById(id).innerHTML = message;
      return false;
    } else {
      document.getElementById(id).style.display = 'none';
      document.getElementById(id).innerHTML = '';
      return true;
    }
  };

  this.checkHoTen = function (inputValue, id, message) {
    var pattern = new RegExp(
      '^[a-zA-Z_ÀÁÂÃÈÉÊẾÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶ' +
        'ẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợ' +
        'ụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹý\\s]+$'
    );

    // nếu input value chứa kí tự tiêng việt ở pattern và khác kí tự đặc biệt (! & ^ *)
    if (pattern.test(inputValue)) {
      document.getElementById(id).style.display = 'none';
      document.getElementById(id).innerHTML = '';
      return true;
    } else {
      document.getElementById(id).style.display = 'block';
      document.getElementById(id).innerHTML = message;
      return false;
    }
  };

  this.checkEmail = function (inputValue, id, message) {
    var pattern = new RegExp(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/);

    // nếu input value chứa kí tự tiêng việt ở pattern và khác kí tự đặc biệt (! & ^ *)
    if (pattern.test(inputValue)) {
      document.getElementById(id).style.display = 'none';
      document.getElementById(id).innerHTML = '';
      return true;
    } else {
      document.getElementById(id).style.display = 'block';
      document.getElementById(id).innerHTML = message;
      return false;
    }
  };

  this.checkPassword = function (inputValue, id, message) {
    var pattern = new RegExp(
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,10}$/
    );

    if (pattern.test(inputValue)) {
      document.getElementById(id).style.display = 'none';
      document.getElementById(id).innerHTML = '';
      return true;
    } else {
      document.getElementById(id).style.display = 'block';
      document.getElementById(id).innerHTML = message;
      return false;
    }
  };

  this.checkLuong = function (inputValue, id, message) {
    var pattern = new RegExp('^[0-9]+$');

    // chỉ chứa kí tự số và lương ít nhất là 1 triệu
    if (pattern.test(inputValue) && inputValue >= 1e6) {
      document.getElementById(id).style.display = 'none';
      document.getElementById(id).innerHTML = '';
      return true;
    } else {
      document.getElementById(id).style.display = 'block';
      document.getElementById(id).innerHTML = message;
      return false;
    }
  };

  this.checkChucVu = function (inputValue, id, message) {
    if (inputValue === 'Chọn chức vụ') {
      document.getElementById(id).style.display = 'block';
      document.getElementById(id).innerHTML = message;
      return false;
    } else {
      document.getElementById(id).style.display = 'none';
      document.getElementById(id).innerHTML = '';
      return true;
    }
  };

  this.checkTime = function (inputValue, id, message) {
    var pattern = new RegExp('^[0-9]+$');
    if (pattern.test(inputValue) && inputValue >= 80 && inputValue <= 200) {
      document.getElementById(id).style.display = 'none';
      document.getElementById(id).innerHTML = '';
      return true;
    } else {
      document.getElementById(id).style.display = 'block';
      document.getElementById(id).innerHTML = message;
      return false;
    }
  };
}
