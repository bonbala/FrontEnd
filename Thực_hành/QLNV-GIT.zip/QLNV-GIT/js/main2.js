//var, let, const

/**
 * Only let vs const
 *
 * let : dùng cho biến, nếu biến đó cần cập nhật lại
 *
 * const: dùng cho biến nếu biến đó ko cập nhật lại và dùng cho function để
 * tránh trường hợp trùng function hoặc cập nhật lại
 *
 */

/**
 * 1.Dự án todo list cho nhân viên
 *
 * Y/C: khi nv vào ca làm sẽ có 1 list danh sách những nhiệm vụ sẽ làm
 *
 * Mong Muốn: Khi nv làm xong sẽ tick vào danh sách nhiệm vụ nó chuyển từ nhiệm vụ sẽ làm sang nhiệm vụ đã hoàn thành
 *
 *
 *
 *
 *
 *
 */
