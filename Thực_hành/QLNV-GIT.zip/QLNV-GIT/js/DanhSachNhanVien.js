function DanhSachNhanVien() {
  this.mang = [];

  this.themNhanVien = function (nhanVien) {
    this.mang.push(nhanVien);
  };

  this.timViTri = function (taiKhoan) {
    var index = this.mang.findIndex((item) => item.taiKhoan === taiKhoan);
    return index;
  };

  this.xoaNhanVien = function (taiKhoan) {
    var index = this.timViTri(taiKhoan);
    this.mang.splice(index, 1);
  };

  this.capNhatNhanVien = function (nhanVien) {
    var index = this.timViTri(nhanVien.taiKhoan);
    this.mang[index] = nhanVien;
  };

  this.timKiemTaiKhoan = function (content) {
    var newListNhanVien = [];
    var chuThuong = content.toLowerCase().replace(/\s/g, '');
    var TaiKhoanKhongDau = chuThuong
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');

    this.mang.forEach((nhanVien) => {
      var taiKhoan = nhanVien.taiKhoan.toLowerCase().replace(/\s/g, '');
      var taiKhoanNhanVienKhongDau = taiKhoan
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');
      var ketQua = taiKhoanNhanVienKhongDau.indexOf(TaiKhoanKhongDau);
      if (ketQua >= 0) {
        newListNhanVien.push(nhanVien);
      }
    });
    return newListNhanVien;
  };
}
