const dsnv = new DanhSachNhanVien();
var val = new Validation();
function getELE(id) {
  return document.getElementById(id);
}

function setLocalStorage() {
  //lưu data dưới local bắt buộc phải convert từ object sang JSON
  //key , //value
  localStorage.setItem('DSNV', JSON.stringify(dsnv.mang));
}

function showDanhSachNhanVien(listNhanVien) {
  var content = '';
  listNhanVien.map((item, index) => {
    content += `
        <tr>
        <td>${item.taiKhoan}</td>
        <td>${item.hoTen}</td>
        <td>${item.email}</td>
        <td>${item.date}</td>
        <td>${item.chucVu}</td>
        <td>${item.tongLuong}</td>
        <td>${item.xepLoai}</td>
        <td class="d-flex">
          <button onclick="xoaNhanVien('${item.taiKhoan}')" class="btn btn-danger mx-1">Xoá</button>
          <button onclick="xemNhanVien('${item.taiKhoan}')"  class="btn btn-success mx-1">Xem</button>
        </td>
      </tr>
        `;
  });

  getELE('tableDanhSach').innerHTML = content;
}

function themNhanVien() {
  var taiKhoan = getELE('tknv').value;
  var name = getELE('name').value;
  var email = getELE('email').value;
  var mk = getELE('password').value;
  var date = getELE('datepicker').value;
  var luong = getELE('luongCB').value;
  var chucVu = getELE('chucvu').value;
  var gioLam = getELE('gioLam').value;
  var isValue = true;

  // check tai khoan
  isValue =
    val.checkEmpty(taiKhoan, 'tbTKNV', 'please text account') &&
    val.checkTK(taiKhoan, 'tbTKNV', 'Account exist', dsnv.mang);

  // check ho va ten
  isValue &=
    val.checkEmpty(name, 'tbTen', 'please text full name') &&
    val.checkHoTen(name, 'tbTen', 'please text full name is valid');

  //check email
  isValue &=
    val.checkEmpty(email, 'tbEmail', 'please text email') &&
    val.checkEmail(email, 'tbEmail', 'please text email is valid');

  // check pass
  // isValue &=
  //   val.checkEmpty(mk, 'tbMatKhau', 'please text password') &&
  //   val.checkPassword(
  //     mk,
  //     'tbMatKhau',
  //     'Password need to 6-10 characters (1 character number, 1 character uppercase, 1 character specical)'
  //   );

  //check date
  isValue &= val.checkEmpty(date, 'tbNgay', 'please text date');

  // check luong
  isValue &=
    val.checkEmpty(luong, 'tbLuongCB', 'please text salary') &&
    val.checkLuong(luong, 'tbLuongCB', 'Salary from 1tr vnd');

  // check chucvu
  isValue &= val.checkChucVu(chucVu, 'tbChucVu', 'Please choice postion');

  // check Time
  isValue &=
    val.checkEmpty(gioLam, 'tbGiolam', 'please text time') &&
    val.checkTime(gioLam, 'tbGiolam', 'please choose time get over');

  //  check thoa man dieu kien
  if (isValue) {
    var nhanVien = new NhanVien(
      taiKhoan,
      name,
      email,
      mk,
      date,
      luong,
      chucVu,
      gioLam
    );

    nhanVien.tongLuong = nhanVien.tinhLuong();
    nhanVien.xepLoai = nhanVien.tinhXepLoai();

    dsnv.themNhanVien(nhanVien);
    showDanhSachNhanVien(dsnv.mang);
    setLocalStorage();
    getELE('form-area').reset();
    getELE('btnDong').click();
  }
}

function getLocalStorage() {
  var valueLocalstorage = localStorage.getItem('DSNV');
  if (valueLocalstorage !== null) {
    // convert JSON to Object
    var listDSNV = JSON.parse(valueLocalstorage);
    dsnv.mang = listDSNV;
    showDanhSachNhanVien(dsnv.mang);
  }
}

function xoaNhanVien(taiKhoan) {
  dsnv.xoaNhanVien(taiKhoan);
  setLocalStorage();
  showDanhSachNhanVien(dsnv.mang);
}

function xemNhanVien(taiKhoan) {
  var viTri = dsnv.timViTri(taiKhoan);
  var nhanVien = dsnv.mang[viTri];
  getELE('tknv').disabled = true;
  getELE('tknv').value = nhanVien.taiKhoan;
  getELE('name').value = nhanVien.hoTen;
  getELE('email').value = nhanVien.email;
  getELE('password').value = nhanVien.mk;
  getELE('datepicker').value = nhanVien.date;
  getELE('luongCB').value = nhanVien.luong;
  getELE('chucvu').value = nhanVien.chucVu;
  getELE('gioLam').value = nhanVien.gioLam;

  // show modal
  document.querySelector('.modal').classList.add('show');
  document.querySelector('.modal').style.display = 'block';

  getELE('btnDong').addEventListener('click', function () {
    // DOM Tới modal để remove class show
    document.querySelector('.modal').classList.remove('show');
    document.querySelector('.modal').style.display = 'none';
    getELE('tknv').disabled = false;
    getELE('btnThemNV').disabled = false;
    getELE('form-area').reset();
  });

  getELE('btnThemNV').disabled = true;
}

function capNhatNhanVien() {
  var taiKhoan = getELE('tknv').value;
  var name = getELE('name').value;
  var email = getELE('email').value;
  var mk = getELE('password').value;
  var date = getELE('datepicker').value;
  var luong = getELE('luongCB').value;
  var chucVu = getELE('chucvu').value;
  var gioLam = getELE('gioLam').value;

  var isValue = true;

  // check ho va ten
  isValue &=
    val.checkEmpty(name, 'tbTen', 'please text full name') &&
    val.checkHoTen(name, 'tbTen', 'please text full name is valid');

  //check email
  isValue &=
    val.checkEmpty(email, 'tbEmail', 'please text email') &&
    val.checkEmail(email, 'tbEmail', 'please text email is valid');

  // check pass
  isValue &=
    val.checkEmpty(mk, 'tbMatKhau', 'please text password') &&
    val.checkPassword(
      mk,
      'tbMatKhau',
      'Password need to 6-10 characters (1 character number, 1 character uppercase, 1 character specical)'
    );

  //check date
  isValue &= val.checkEmpty(date, 'tbNgay', 'please text date');

  // check luong
  isValue &=
    val.checkEmpty(luong, 'tbLuongCB', 'please text salary') &&
    val.checkLuong(luong, 'tbLuongCB', 'Salary from 1tr vnd');

  // check chucvu
  isValue &= val.checkChucVu(chucVu, 'tbChucVu', 'Please choice postion');

  // check Time
  isValue &=
    val.checkEmpty(gioLam, 'tbGiolam', 'please text time') &&
    val.checkTime(gioLam, 'tbGiolam', 'please choose time get over');

  if (isValue) {
    var nhanVien = new NhanVien(
      taiKhoan,
      name,
      email,
      mk,
      date,
      luong,
      chucVu,
      gioLam
    );

    nhanVien.tongLuong = nhanVien.tinhLuong();
    nhanVien.xepLoai = nhanVien.tinhXepLoai();

    dsnv.capNhatNhanVien(nhanVien);
    showDanhSachNhanVien(dsnv.mang);
    setLocalStorage();
    alert('Update successfully');
    getELE('form-area').reset();
    getELE('btnDong').click();
  }
}

function handleSearch() {
  var content = getELE('searchName').value;
  var newListNhanVien = dsnv.timKiemTaiKhoan(content);
  showDanhSachNhanVien(newListNhanVien);
}

// lúc load trang thì sẽ lấy data ở dưới local storage lên và showDanhSaschNV()
getLocalStorage();
getELE('btnThemNV').addEventListener('click', themNhanVien);
getELE('btnCapNhat').addEventListener('click', capNhatNhanVien);
getELE('btnTimNV').addEventListener('click', handleSearch);
